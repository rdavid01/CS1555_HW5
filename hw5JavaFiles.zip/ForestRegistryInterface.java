// David Reidenbaugh (dmr117)
// Eric Copeland (ejc76)

import java.io.*;
import java.util.*;
import java.sql.*;

public class ForestRegistryInterface{
    public static void main(String args[]) throws
            ClassNotFoundException, SQLException {

        //check if jdbc driver is properly linked
        Class.forName("org.postgresql.Driver");

        //connection
        String url = "jdbc:postgresql://localhost:5432/";
//         String url = "jdbc:postgresql://class3.cs.pitt.edu:5432/";
        Properties props = new Properties();
        props.setProperty("user", "postgres");
//         props.setProperty("user", "dmr117");
        props.setProperty("password", "skuleStinks");
//         props.setProperty("password", "<password here>");

        //connection
        Connection conn = DriverManager.getConnection(url, props);

        Scanner userInput = new Scanner(System.in);
        boolean terminated = false;

        System.out.println("Hello, this is the user interface for the US Forest Registry.");
        showOptions();

        while(!terminated){
            char functionChoice = '!';
            //get user choice
            System.out.println("\n-------------------------------------------------------------------------");
            System.out.println("\nChoose from actions 1-8, type 9 to show options again, or type 0 to quit.");
            try{
                functionChoice = userInput.next().charAt(0);
                System.out.println("");//extra blank line may help with readability
            }
            catch(NoSuchElementException e){
                System.out.println("invalid input, please chose a character from the list of options.");
            }

            //perform action based on user choice
            switch(functionChoice){
                case '1':
                    try{
                        System.out.println("Your choice: Add Forest\n");
                        AddForest.main(args);
                    }
                    catch(ClassNotFoundException e){
                        System.out.println("Class not found");
                    }
                    catch(SQLException e1){
                        System.out.println("SQL exception");
                    }
                    break;

                case '2':
                    try{
                        System.out.println("Your choice: Add Worker\n");
                        AddWorker.main(args);
                    }
                    catch(ClassNotFoundException e){
                        System.out.println("Class not found");
                    }
                    catch(SQLException e1){
                        System.out.println("SQL exception");
                    }
                    break;

                case '3':
                    try{
                        System.out.println("Your choice: Add Sensor\n");
                        AddSensor.main(args);
                    }
                    catch(ClassNotFoundException e){
                        System.out.println("Class not found");
                    }
                    catch(SQLException e1){
                        System.out.println("SQL exception");
                    }
                    break;

                case '4':
                    try{
                        System.out.println("Your choice: Switch Workers' Duties Workers Duties\n");
                        SwitchWorkersDuties.main(args);
                    }
                    catch(ClassNotFoundException e){
                        System.out.println("Class not found");
                    }
                    catch(SQLException e1){
                        System.out.println("SQL exception");
                    }
                    break;

                case '5':
                    try{
                        System.out.println("Your choice: Update Sensor Status");
                        UpdateSensorStatus.main(args);
                    }
                    catch(ClassNotFoundException e){
                        System.out.println("Class not found");
                    }
                    catch(SQLException e1){
                        System.out.println("SQL exception");
                    }
                    break;

                case '6':
                    try{
                        System.out.println("Your choice: Update Forest Covered Area");
                        UpdateForestCoveredArea.main(args);
                    }
                    catch(ClassNotFoundException e){
                        System.out.println("Class not found");
                    }
                    catch(SQLException e1){
                        System.out.println("SQL exception");
                    }
                    break;

                case '7':
                    try{
                        System.out.println("Your choice: Find Top-K Busy Workers");
                        TopKBusyWorkers.main(args);
                    }
                    catch(ClassNotFoundException e){
                        System.out.println("Class not found");
                    }
                    catch(SQLException e1){
                        System.out.println("SQL exception");
                    }
                    break;

                case '8':
                    try{
                        System.out.println("Your choice: Display Sensors Ranking");
                        DisplaySensorsRanking.main(args);
                    }
                    catch(ClassNotFoundException e){
                        System.out.println("Class not found");
                    }
                    catch(SQLException e1){
                        System.out.println("SQL exception");
                    }
                    break;

                case '9':
                    showOptions();
                    break;

                case '0':
                    terminated = true;
                    break;

                default:
                    System.out.println("\n" + functionChoice + " is not a valid option, please select from the following.\n");
                    showOptions();

            }
        }
    }

    private static void showOptions(){
        System.out.println("\nPlease select the number corresponding to the action you would like to take:\n " +
                            "\t1: Add Forest\n" +
                            "\t2: Add Worker\n" +
                            "\t3: Add Sensor\n" +
                            "\t4: Switch Workers' Duties\n" +
                            "\t5: Update Sensor Status\n" +
                            "\t6: Update Forest Covered Area\n" +
                            "\t7: Find Top-K Busy Workers\n" +
                            "\t8: Display Sensors Ranking\n" +
                            "\t9: Show Options Again\n" +
                            "\t0: Quit\n");
    }
}