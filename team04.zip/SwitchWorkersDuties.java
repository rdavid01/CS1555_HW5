// David Reidenbaugh (dmr117)
// Eric Copeland (ejc76)

//NOTE: Will not be affected if neither worker maintains any sensors (just swaps nothing)
import java.io.*;
import java.util.*;
import java.sql.*;

public class SwitchWorkersDuties {
    public static void main(String args[]) throws
            ClassNotFoundException, SQLException {

        //check if jdbc driver is properly linked
        Class.forName("org.postgresql.Driver");

        //connection
        String url = "jdbc:postgresql://class3.cs.pitt.edu:5432/";
        Properties props = new Properties();
        props.setProperty("user", "dmr117");
        props.setProperty("password", "<password here>");

        //connection
        Connection conn = DriverManager.getConnection(url, props);

        Scanner userInput = new Scanner(System.in);

        String workerName1 = null;
        String workerName2 = null;
        boolean exceptionOccurred = false;

        //gather inputs from user one at a time
        //workerName1
        System.out.println("\nPlease enter name of the first worker who will be swapping duties (Worker #1).");
        try{
            workerName1 = userInput.nextLine().toUpperCase();
        }
        catch(NoSuchElementException e){
            exceptionOccurred = true;
            System.out.println("\nNoSuchElementException for for worker#1.");
            System.out.println("Please try again and provide a valid worker name for Worker #1.");
        }

        //workerName2
        if(!exceptionOccurred){
            System.out.println("\nPlease enter name of the second worker who will be swapping duties (Worker #2).");
            try{
                workerName2 = userInput.nextLine().toUpperCase();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for for worker#2.");
                System.out.println("Please try again and provide a valid worker name for Worker #2.");
            }
        }

        //create queries and insert statements

        //get worker ssn's and state's---------
        String ssn1 = null;
        String state1 = null;
        String ssn2 = null;
        String state2 = null;
        if(!exceptionOccurred){
            try{
                String getWorker1 = "SELECT SSN, employing_state FROM Worker WHERE Name = ?";
                String getWorker2 = "SELECT SSN, employing_state FROM Worker WHERE Name = ?";

                PreparedStatement pstGet1 = conn.prepareStatement(getWorker1);
                PreparedStatement pstGet2 = conn.prepareStatement(getWorker2);
                pstGet1.setString(1, workerName1);
                pstGet2.setString(1, workerName2);

                //get ssn and state for worker1
                ResultSet rs1 = pstGet1.executeQuery();
                while(rs1.next()){
                    ssn1 = rs1.getString("ssn");
                    state1 = rs1.getString("employing_state");
                }
                //let user know if such a worker doesn't exist
                if(ssn1 == null){
                    exceptionOccurred = true; //set to true so that will not try to switch with invalid names
                    System.out.println("\nA worker with the name " + workerName1 + " does not exist.");;
                };

                //get ssn and state for worker2
                ResultSet rs2 = pstGet2.executeQuery();
                while(rs2.next()){
                    ssn2 = rs2.getString("ssn");
                    state2 = rs2.getString("employing_state");
                }
                //let user know if such a worker does not exist
                if(ssn2 == null){
                    exceptionOccurred = true; //set to true so that will not try to switch with invalid names
                    System.out.println("\nA worker with the name " + workerName2 + " does not exist.");;
                };
            }
            catch(SQLException e){
                exceptionOccurred = true;
                while(e != null){
                    System.out.println("Message = " + e.getMessage());
                    System.out.println("SQLState = "+ e.getSQLState());
                    System.out.println("SQL Code = "+ e.getErrorCode());
                    e = e.getNextException();
                }
            }
        }


        //perform operations on DB if possible
        if(!exceptionOccurred){
            try{
               conn.setAutoCommit(false);

               //set contraints deferred
               String setDeferred = "SET CONSTRAINTS ALL DEFERRED";
               PreparedStatement defer = conn.prepareStatement(setDeferred);

               //set a temp value as the maintainer of worker1's sensors
               String setTemp = "UPDATE SENSOR " +
                              "SET maintainer = 'temp' " +
                              "WHERE maintainer = ?";
               PreparedStatement toTemp = conn.prepareStatement(setTemp);
               toTemp.setString(1, ssn1);

                //set worker1 to maintain worker2's sensors (where the sensor is in worker1's state)
                    //uses view sensor_states so that only try to switch if receving worker is in valid same state as sensor being traded
               String to1 = "UPDATE SENSOR " +
                              "SET maintainer = ? " +
                              "WHERE sensor_id in ( select sensor_id " +
                                                  "from sensor_states " +
                                                  "where maintainer = ? and state = ?)";
//                               "WHERE maintainer = ?";
               PreparedStatement from2 = conn.prepareStatement(to1);
               from2.setString(1, ssn1);
               from2.setString(2, ssn2);
               from2.setString(3, state1);

                //set worker2 to maintain sensors marked temp (worker1's old sensors) where the sensor is in worker2's state
               String to2 = "UPDATE SENSOR " +
                              "SET maintainer = ? " +
                              "WHERE sensor_id in ( select sensor_id " +
                                                  "from sensor_states " +
                                                  "where maintainer = 'temp' and state = ?)";
//                               "WHERE maintainer = 'temp'";
               PreparedStatement from1 = conn.prepareStatement(to2);
               from1.setString(1, ssn2);
               from1.setString(2, state2);

               //Worker1 is set to maitain tuples marked 'temp' (sensors that worker2 couldn't manage)
               String tempTo1 = "UPDATE SENSOR " +
                                "SET maintainer = ? " +
                                "WHERE maintainer = 'temp'";
               PreparedStatement giveBackTo1 = conn.prepareStatement(tempTo1);
               giveBackTo1.setString(1, ssn1);


              defer.executeUpdate();
              toTemp.executeUpdate();
              from2.executeUpdate();
              from1.executeUpdate();
              giveBackTo1.executeUpdate();


              conn.commit();

              //success message
              System.out.println("\nsuccessfully switch " + workerName1 + "\'s sensors with " + workerName2 + "\'s sensors where it was possible.\n");

            }
            catch(SQLException e){
                exceptionOccurred = true;
                while(e != null){
                    System.out.println("Message = " + e.getMessage());
                    System.out.println("SQLState = "+ e.getSQLState());
                    System.out.println("SQL Code = "+ e.getErrorCode());
                    e = e.getNextException();
                }
                try{
                   conn.rollback();
                }
                catch(SQLException e1){
                   System.out.println(e1.toString());
                }
            }
        }
    }
}