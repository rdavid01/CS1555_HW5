// David Reidenbaugh (dmr117)
// Eric Copeland (ejc76)

//!!! switch url, user, and password from local host to class3 host before submittin
import java.io.*;
import java.util.*;
import java.sql.*;

public class AddWorker {
    public static void main(String args[]) throws
            ClassNotFoundException, SQLException {

        //check if jdbc driver is properly linked
        Class.forName("org.postgresql.Driver");

        //connection
        String url = "jdbc:postgresql://localhost:5432/";
//         String url = "jdbc:postgresql://class3.cs.pitt.edu:5432/";
        Properties props = new Properties();
        props.setProperty("user", "postgres");
//         props.setProperty("user", "dmr117");
        props.setProperty("password", "skuleStinks");
//         props.setProperty("password", "<password here>");

        //connection
        Connection conn = DriverManager.getConnection(url, props);

        Scanner userInput = new Scanner(System.in);

        String ssn = null;
        String name = null;
        int rank = 0;
        String state = null;
        boolean exceptionOccurred = false;

        //gather inputs from user one at a time
        //ssn
        System.out.println("Please enter the worker's ssn as a nine digit numeric value without spaces.");
        try{
            ssn = userInput.nextLine();
            //test that string only contains numeric values
            try{
                int testSSN = Integer.parseInt(ssn);
            }
            catch(NumberFormatException e){
                exceptionOccurred = true;
                System.out.println("\nNumberFormatException for attribute ssn."
                                    + "\nPlease make sure that the ssn is a nine digit numeric value."
                                    + "\nssn cannot contain any letters or spaces.");
            }
            //test that length is exactly nine digits
            if(!(ssn.length() == 9)){
                throw new NoSuchElementException();
            }
        }
        catch(NoSuchElementException e){
            exceptionOccurred = true;
            System.out.println("\nNoSuchElementException for attribute ssn");
            System.out.println("Please try again and provide a nine digit numeric value.");
        }

        //name
        if(!exceptionOccurred){
            System.out.println("Please enter the worker's name.");
            try{
                name = userInput.nextLine().toUpperCase(); //worker name converted to all upper case letters
                                                                //simpler in case need to search for worker name
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for attribute name");
                System.out.println("Please try again and provide the worker's name.");
            }
        }

        //rank
        if(!exceptionOccurred){
            System.out.println("Please enter the worker's rank as a numeric value.");
            try{
                rank = userInput.nextInt();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for attribute rank");
                System.out.println("Please try again and provide a numeric value for rank.");
            }
        }

        //state
        if(!exceptionOccurred){
            System.out.println("Please enter the abbreviation for the state in which the worker is employed."
                                + "(Ex. if the state is Pennsylvania, provide the abbreviation of \'PA\'");
            try{
                state = userInput.next().toUpperCase();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for the employing state.");
                System.out.println("Please try again and provide an abbreviation for state.");
            }
        }


        //perform operations on DB if possible
        if(!exceptionOccurred){
            try{
                conn.setAutoCommit(false); //make so that all db accesses/modifications are part of a transaction
                                                //worker insertion should follow acid properties to maintain safe database
                //insert the worker --------
                String insertWorker = "insert into worker values (?, ?, ?, ?)";

                //set up PreparedStatement
                PreparedStatement pst = conn.prepareStatement(insertWorker);
                pst.setString(1, ssn);
                pst.setString(2, name);
                pst.setInt(3, rank);
                pst.setString(4, state);

                pst.executeUpdate();

                //print success message
                System.out.println("\nWorker named " + name + " successfully added\n.");
                conn.commit();

            }
            catch(SQLException e){
                exceptionOccurred = true;
                while(e != null){
                    System.out.println("Message = " + e.getMessage());
                    System.out.println("SQLState = "+ e.getSQLState());
                    System.out.println("SQL Code = "+ e.getErrorCode());
                    e = e.getNextException();
                }
                try{
                   conn.rollback();
                }
                catch(SQLException e1){
                   System.out.println(e1.toString());
                }
            }
        }
    }
}