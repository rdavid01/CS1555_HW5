// David Reidenbaugh (dmr117)
// Eric Copeland (ejc76)

//!!! switch url, user, and password from local host to class3 host before submittin
import java.io.*;
import java.util.*;
import java.sql.*;

public class AddSensor {
    public static void main(String args[]) throws
            ClassNotFoundException, SQLException {

        //check if jdbc driver is properly linked
        Class.forName("org.postgresql.Driver");

        //connection
        String url = "jdbc:postgresql://localhost:5432/";
//         String url = "jdbc:postgresql://class3.cs.pitt.edu:5432/";
        Properties props = new Properties();
        props.setProperty("user", "postgres");
//         props.setProperty("user", "dmr117");
        props.setProperty("password", "skuleStinks");
//         props.setProperty("password", "<password here>");

        //connection
        Connection conn = DriverManager.getConnection(url, props);

        Scanner userInput = new Scanner(System.in);

        float xCoord = 0;
        float yCoord = 0;
        int chargeMonth = 0;
        int chargeDay = 0;
        int chargeYear = 0;
        int chargeHour = 0;
        int chargeMinute = 0;
        String maintainerID = null;
        int readMonth = 0;
        int readDay = 0;
        int readYear = 0;
        int readHour = 0;
        int readMinute = 0;
        int energy = 0;
        boolean exceptionOccurred = false;

        //gather inputs from user one at a time
            //sensor id generated automatically at insertion time
        //x coordinate
        System.out.println("Please enter the sensor's x coordinate as a numeric value.");
        try{
            xCoord = userInput.nextFloat();
        }
        catch(NoSuchElementException e){
            exceptionOccurred = true;
            System.out.println("\nNoSuchElementException for attribute x coordinate.");
            System.out.println("Please try again and provide a numeric value.");
        }

        //y coordinate
        if(!exceptionOccurred){
            System.out.println("Please enter the sensor's y coordinate as a numeric value.");
            try{
                yCoord = userInput.nextFloat();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for attribute y coordinate");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //charge year
        if(!exceptionOccurred){
            System.out.println("Please enter year of sensor's last charge time."
                                +"\n (Ex. if the year was 2020, type \'2020\'.)");
            try{
                chargeYear = userInput.nextInt();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for charge year");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //charge month
        if(!exceptionOccurred){
            System.out.println("Please enter the month number of sensor's last charge time."
                                +"\n (Ex. if the month was January, type \'1\'.)");
            try{
                chargeMonth = userInput.nextInt();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for charge month");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //charge day
        if(!exceptionOccurred){
            System.out.println("Please enter the day number of the month of sensor's last charge time."
                                +"\n (Ex. if the day was the 12th of January, type \'12\'.)");
            try{
                chargeDay = userInput.nextInt();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for charge day");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //charge hour
        if(!exceptionOccurred){
            System.out.println("Please enter the hour (using 24-hour clock) of sensor's last charge time."
                                +"\n (Ex. if the hour was 5PM, type \'17\'.)");
            try{
                chargeHour = userInput.nextInt();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for charge hour");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //charge minute
        if(!exceptionOccurred){
            System.out.println("Please enter the minute of sensor's last charge time."
                                +"\n (Ex. if the time was was 5:25, type \'25\'.)");
            try{
                chargeMinute = userInput.nextInt();

            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for charge minute");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //maintainerID
        if(!exceptionOccurred){
            System.out.println("Please enter the nine digit ID of the sensor's maintainer."
                                + "\n If there is no maintainer, please enter \'null\'");
            try{
                maintainerID = userInput.next().toUpperCase();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for maintainer");
                System.out.println("Please try again and provide a valid nine digit ID.");
            }
        }

        //read year
        if(!exceptionOccurred){
            System.out.println("Please enter year of sensor's last read time."
                                +"\n (Ex. if the year was 2020, type \'2020\'.)");
            try{
                readYear = userInput.nextInt();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for read year");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //read month
        if(!exceptionOccurred){
            System.out.println("Please enter the month number of sensor's last read time."
                                +"\n (Ex. if the month was January, type \'1\'.)");
            try{
                readMonth = userInput.nextInt();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for read month");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //read day
        if(!exceptionOccurred){
            System.out.println("Please enter the day number of the month of sensor's last read time."
                                +"\n (Ex. if the day was the 12th of January, type \'12\'.)");
            try{
                readDay = userInput.nextInt();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for read day");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //read hour
        if(!exceptionOccurred){
            System.out.println("Please enter the hour (using 24-hour clock) of sensor's last read time."
                                +"\n (Ex. if the hour was 5PM, type \'17\'.)");
            try{
                readHour = userInput.nextInt();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for read hour");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //read minute
        if(!exceptionOccurred){
            System.out.println("Please enter the minute of sensor's last read time."
                                +"\n (Ex. if the time was was 4:25, type \'25\'.)");
            try{
                readMinute = userInput.nextInt();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for read minute");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //energy
        if(!exceptionOccurred){
            System.out.println("Please energy level of this sensor as a numeric value.");
            try{
                energy = userInput.nextInt();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for attribute energy");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //use inputs to make timestamps
        String lastChargeStr = (chargeYear + "-" + chargeMonth + "-" + chargeDay
                                + " " + chargeHour + ":" + chargeMinute + ":" + "00");
        String lastReadStr = (readYear + "-" + readMonth + "-" + readDay
                              + " " + readHour + ":" + readMinute + ":" + "00");

        Timestamp lastChargeStamp = null;
        Timestamp lastReadStamp = null;

        if(!exceptionOccurred){
            try{
                lastChargeStamp = Timestamp.valueOf(lastChargeStr);
                lastReadStamp = Timestamp.valueOf(lastReadStr);
            }
            catch(IllegalArgumentException e){
                exceptionOccurred = true;
                System.out.println("\nIllegalArgumentException for generating timestamp.");
                System.out.println("Please try again and make sure all dates and times provided are the appropriate lengths.");

            }
        }


        //perform operations on DB if possible
        if(!exceptionOccurred){
            try{
                conn.setAutoCommit(false); //make so that all db accesses/modifications are part of a transaction
                                                //sensor insertion should follow acid properties to maintain safe database
                //insert the sensor ---------
                String insertSensor = "insert into sensor values (?, ?, ?, ?, ?, ?, ?)";

                //set up PreparedStatement
                PreparedStatement pst = conn.prepareStatement(insertSensor);
                pst.setInt(1, 0);
                pst.setFloat(2, xCoord);
                pst.setFloat(3, yCoord);
                pst.setTimestamp(4, lastChargeStamp);
                if(maintainerID.equals("NULL")){          //allow for maintainerID to be null
                    pst.setNull(5, Types.VARCHAR);
                }
                else{
                    pst.setString(5, maintainerID);
                }
                pst.setTimestamp(6,lastReadStamp);
                pst.setInt(7,energy);

                pst.executeUpdate();


                //find the sensor id---------
                String getSensorId = "select max(sensor_id) as max from sensor";

                int newSensorId = 0;
                Statement st = conn.createStatement();

                ResultSet rs = st.executeQuery(getSensorId);
                while(rs.next()){
                    newSensorId = rs.getInt("max");
                }


                //print out success message
                System.out.println("\nSensor Id: " + newSensorId + ", x coordinate: " +xCoord + ", y coordinate: " + yCoord + " successfully added.\n");

                //commit ------
                conn.commit();
            }
            catch(SQLException e){
                exceptionOccurred = true;
                while(e != null){
                    System.out.println("Message = " + e.getMessage());
                    System.out.println("SQLState = "+ e.getSQLState());
                    System.out.println("SQL Code = "+ e.getErrorCode());

                    String sqlState = e.getSQLState();
                    if(sqlState.equals("2D000")){
                        System.out.println("\nPlease make sure the sensor's coordinates are in the same state as its maintainer is employed.");
                    }

                    e = e.getNextException();
                }
                try{
                   conn.rollback();
                }
                catch(SQLException e1){
                   System.out.println(e1.toString());
                }
            }
        }
    }
}