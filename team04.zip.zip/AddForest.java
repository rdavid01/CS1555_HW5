// David Reidenbaugh (dmr117)
// Eric Copeland (ejc76)

//ASSUMPTION: a forest should only be added to forest table if it can also be successfully added to coverage table
//NOTE: NoSuchElementException was chosen over InputMismatchException for invalid user inputs because it also covers the case where user presses something like ctrl+c

import java.io.*;
import java.util.*;
import java.sql.*;

public class AddForest{
    public static void main(String args[]) throws
            ClassNotFoundException, SQLException {

        //check if jdbc driver is properly linked
        Class.forName("org.postgresql.Driver");

        //connection
        String url = "jdbc:postgresql://class3.cs.pitt.edu:5432/";
        Properties props = new Properties();
        props.setProperty("user", "dmr117");
        props.setProperty("password", "<password here>");

        //connection
        Connection conn = DriverManager.getConnection(url, props);

        Scanner userInput = new Scanner(System.in);

        String name = null;
        float area = 0;
        float acidLevel = 0;
        float xMin = 0;
        float xMax = 0;
        float yMin = 0;
        float yMax = 0;
        String coverageState = null;
        boolean exceptionOccurred = false;


        //gather inputs from user one at a time
            //forest number generated automatically at insertion time (using trigger)
        //forest name
        System.out.println("\nPlease enter the forest's name.");
        try{
            name = userInput.nextLine().toUpperCase();
            //raise exception if user try to input empty string
            if(name.length() == 0){
                exceptionOccurred = true;
                System.out.println("\nThe forest name cannot be empty.");
                throw new NoSuchElementException();
            }
        }
        catch(NoSuchElementException e){
            exceptionOccurred = true;
            System.out.println("\nNoSuchElementException for attribute name");
            System.out.println("Please try again and provide a name for the forest.");
        }

        //state abbreviation
        if(!exceptionOccurred){
            System.out.println("\nPlease enter the abbreviation for the state to which the forest resides."
                                + " (Ex. if the state is Pennsylvania, provide the abbreviation of \'PA\'");
            try{
                coverageState = userInput.nextLine().toUpperCase();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for the state.");
                System.out.println("Please try again and provide an abbreviation for state.");
            }
        }

        //forest area
        if(!exceptionOccurred){
            System.out.println("\nPlease enter the forest's area as a numeric value.");
            try{
                area = userInput.nextFloat();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for attribute area");
                System.out.println("Please try again and provide a numeric value for area.");
            }
        }

        //acid level
        if(!exceptionOccurred){
            System.out.println("\nPlease enter a value for the forest's acid level as a numeric value " +
                                "between 0 and 1. (EX. for 75% acid level, type \"0.75\".)");
            try{
                acidLevel = userInput.nextFloat();
                //if acid level not in bounds, throw input mismatch exe
                if(acidLevel < 0 || acidLevel > 1){
                    throw new NoSuchElementException();
                }
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for attribute acid_level");
                System.out.println("Please try again and provide a numeric value between 0 and 1.");
            }
        }

        //min x
        if(!exceptionOccurred){
            System.out.println("\nPlease enter the forest's min X value for the MBR as a numeric value.");
            try{
                xMin = userInput.nextFloat();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for attribute xMin");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //max x
        if(!exceptionOccurred){
            System.out.println("\nPlease enter the forest's max X value for the MBR as a numeric value.");
            try{
                xMax = userInput.nextFloat();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for attribute xMax");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //min y
        if(!exceptionOccurred){
            System.out.println("\nPlease enter the forest's min Y value for the MBR as a numeric value.");
            try{
                yMin = userInput.nextFloat();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for attribute yMin");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //max y
        if(!exceptionOccurred){
            System.out.println("\nPlease enter the forest's max Y value for the MBR as a numeric value.");
            try{
                yMax = userInput.nextFloat();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for attribute yMax");
                System.out.println("Please try again and provide a numeric value.");
            }
        }







        //perform operations on DB if possible
        if(!exceptionOccurred){
            try{
                conn.setAutoCommit(false); //make so that all db accesses/modifications are part of a transaction
                                                //forest insert should only go through if coverage insert is successful

                //insert the forest---------------
                //string for query to insert new forest
                String insertForest = "insert into forest values (?, ?, ?, ?, ?, ?, ?, ?)"; //using inside of Statement and PreparedStatement to prevent sql injection
                //set up prepareStatement
                PreparedStatement pst = conn.prepareStatement(insertForest);
                pst.setString(1, "0");
                pst.setString(2, name);
                pst.setFloat(3, area);
                pst.setFloat(4, acidLevel);
                pst.setFloat(5, xMin);
                pst.setFloat(6, xMax);
                pst.setFloat(7, yMin);
                pst.setFloat(8, yMax);

                pst.executeUpdate();


                //find the forest number------------
                //string for query to find newly inserted forest_no
                String getForestNum =  "select max(cast(forest_no as integer)) as max from forest";

                String covForestNum = null;
                Statement st = conn.createStatement();

                ResultSet rs = st.executeQuery(getForestNum);
                while(rs.next()){
                    covForestNum = rs.getString("max");
                }


                //insert the coverage tuple----------------
                //string for query to insert a tuple into coverage
                String insertCoverage = "insert into coverage values (?, ?, ?, ?)";
                //reset the PreparedStatement to insert to coverage
                pst = conn.prepareStatement(insertCoverage);

                pst.setString(1, covForestNum);
                pst.setString(2, coverageState);
                pst.setFloat(3, 1);
                pst.setFloat(4, area);

                pst.executeUpdate();

                conn.commit();

                //print out success message (after transactioin commits successfully)
                System.out.println("\nForest Number " + covForestNum + " successfully added.\n");
            }
            catch (SQLException e) {
                //in case of sql exception, will print out information about error
                    //ex. if forest with same name already exists, will let user know primary key constraint violated
                while(e != null){
                    System.out.println("Message = " + e.getMessage());
                    System.out.println("SQLState = "+ e.getSQLState());
                    System.out.println("SQL Code = "+ e.getErrorCode());
                    e = e.getNextException();
                }
                try {
                    conn.rollback();
                } catch (SQLException e1) {
                    System.out.println(e1.toString());
                }
            }
        }
    }
}
