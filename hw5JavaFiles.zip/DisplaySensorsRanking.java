// David Reidenbaugh (dmr117)
// Eric Copeland (ejc76)

//!!! switch url, user, and password from local host to class3 host before submittin
import java.io.*;
import java.util.*;
import java.sql.*;

public class DisplaySensorsRanking {
    public static void main(String args[]) throws
            ClassNotFoundException, SQLException {

        //check if jdbc driver is properly linked
        Class.forName("org.postgresql.Driver");

        //connection
        String url = "jdbc:postgresql://localhost:5432/";
//         String url = "jdbc:postgresql://class3.cs.pitt.edu:5432/";
        Properties props = new Properties();
        props.setProperty("user", "postgres");
//         props.setProperty("user", "dmr117");
        props.setProperty("password", "skuleStinks");
//         props.setProperty("password", "<password here>");

        //connection
        Connection conn = DriverManager.getConnection(url, props);

        //rank sensor's based on the number of reports generated
            //query returns columns  'sensor_id', 'count', 'rank'  in this order
        try{
            String rankReports = "select countReport.sensor_id, countReport.count, RANK() OVER ( " +
                                                                      "order by count desc " +
                                                                    ") as rank " +
                                   "from ( " +
                                             "select sensor_id, count(R.sensor_id) as count " +
                                             "from report as R " +
                                             "group by sensor_id " +
                                             "order by count desc " +
                                         ") as countReport";
            //get the senors who rank #1
                //query returns columns  'rank', 'sensor_id', and 'count'  in this order
            String rankOne = "select rank, sensor_id, count " +
                             "from ( " +
                             rankReports +
                             " ) as rankedReports " +
                             "where rank = 1";

            PreparedStatement pst = conn.prepareStatement(rankOne);
            int sensorID = 0;
            int numReports = 0;
            int rank = 0;

            //print out rank results
            System.out.println("The following senors have generated the most number of reports (been the most active):");
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                rank = rs.getInt("rank");
                sensorID = rs.getInt("sensor_id");
                numReports = rs.getInt("count");
                System.out.print("\tSensor ID: " + sensorID);
                System.out.print("\tNumber of Reports: " + numReports + "\n");
            }

            //no reports
            if(rank == 0){
                System.out.println("\tThere are no reports at this time.\n");
            }
        }
        catch(SQLException e) {
            while(e != null){
                System.out.println("Message = " + e.getMessage());
                System.out.println("SQLState = "+ e.getSQLState());
                System.out.println("SQL Code = "+ e.getErrorCode());
                e = e.getNextException();
            }
            try {
                conn.rollback();
            } catch (SQLException e1) {
                System.out.println(e1.toString());
            }
        }

    }
}