// David Reidenbaugh (dmr117)
// Eric Copeland (ejc76)

//!!! switch url, user, and password from local host to class3 host before submitting
//!!! uses a trigger to catch that area for all entries of a particular forest in coverage does not exceed 100% of state's area

import java.io.*;
import java.util.*;
import java.sql.*;

public class UpdateForestCoveredArea {
    public static void main(String args[]) throws
            ClassNotFoundException, SQLException {

        //check if jdbc driver is properly linked
        Class.forName("org.postgresql.Driver");

        //connection
        String url = "jdbc:postgresql://localhost:5432/";
//         String url = "jdbc:postgresql://class3.cs.pitt.edu:5432/";
        Properties props = new Properties();
        props.setProperty("user", "postgres");
//         props.setProperty("user", "dmr117");
        props.setProperty("password", "skuleStinks");
//         props.setProperty("password", "<password here>");

        //connection
        Connection conn = DriverManager.getConnection(url, props);

        Scanner userInput = new Scanner(System.in);

        String name = null;
        float area = 0;
        String coverageState = null;
        boolean exceptionOccurred = false;


        //gather inputs from user one at a time
        //forest name
        System.out.println("Please enter the forest's name.");
        try{
            name = userInput.nextLine().toUpperCase();
        }
        catch(NoSuchElementException e){
            exceptionOccurred = true;
            System.out.println("\nNoSuchElementException for attribute name");
            System.out.println("Please try again and provide a numeric value for area.");
        }

        //state abbreviation
        if(!exceptionOccurred){
            System.out.println("Please enter the abbreviation for the state which the forest spans."
                                + " (Ex. if the state is Pennsylvania, provide the abbreviation of \'PA\'");
            try{
                coverageState = userInput.nextLine().toUpperCase();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for the state.");
                System.out.println("Please try again and provide an abbreviation for state.");
            }
        }

        //forest area
        if(!exceptionOccurred){
            System.out.println("Please enter the forest's new coverage area as a numeric value." +
                                "The coverage area for a state cannot exceed the area of the state itself.");
            try{
                area = userInput.nextFloat();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for attribute area");
                System.out.println("Please try again and provide a numeric value for area.");
            }
        }

        //update the DB
        if(!exceptionOccurred){
            try{
                   conn.setAutoCommit(false);
               //find forest number -----------------
                   String getForestNum =  "select forest_no, area from forest where name = ?";

                   PreparedStatement pstGetFNum = conn.prepareStatement(getForestNum);
                   pstGetFNum.setString(1, name);

                   String forestNum = null;
                   float forestArea = 0;
                   ResultSet currFNum = pstGetFNum.executeQuery();
                   while(currFNum.next()){
                        forestNum = currFNum.getString("forest_no");
                        forestArea = currFNum.getInt("area");
                   }
               //if forest not found, is invalid
                   if(forestNum == null){
                        exceptionOccurred = true;
                        System.out.println("\nThere is no such forest in the database named " + name + ".\n");
                   }


               //check state is valid------------------------
                   float oldCovArea = 0;
                   if(!exceptionOccurred){
                       String getState = "select state, area from coverage where forest_no = ? and state = ?";

                       PreparedStatement pstGetState = conn.prepareStatement(getState);
                       pstGetState.setString(1, forestNum);
                       pstGetState.setString(2, coverageState);

                       String stateName = null; //used to check if forest exists as an entry in coverage with the desired state

                       ResultSet currState = pstGetState.executeQuery();
                       while(currState.next()){
                            String temp = currState.getString("state");
                            if(temp.equals(coverageState)){
                                oldCovArea = currState.getInt("area"); //old coverage area
                                stateName = temp;                      // state's abbreviation
                            }
                       }

                        //if state name not found in query, the state is not in the DB
                       if(stateName == null){
                            exceptionOccurred = true;
                            System.out.println("\nThe forest " + name + " does not have coverage with the state " + coverageState + ".\n");
                       }
                   }

               //check area valid---------------------
                    //area of coverages cannot be greater than actual area of forest
                        //this is caught by percentage_tri in team04.sql and rolled back by that trigger
                        //the check below just provides an error message giving the user details about why this failure is happening
                   if(!exceptionOccurred){
                       String areaCheck = "select sum(area) as totalCovArea " +
                                            "from coverage " +
                                            "where forest_no = ?";
                       PreparedStatement pstCheckNewArea = conn.prepareStatement(areaCheck);
                       pstCheckNewArea.setString(1, forestNum);

                       float areaSumBeforeUpdate = 0; //area of coverage for forest before coverage updated

                       ResultSet currArea = pstCheckNewArea.executeQuery();
                       while(currArea.next()){
                            areaSumBeforeUpdate = currArea.getFloat("totalCovArea");
                       }

                       float areaSumAfterUpdate = areaSumBeforeUpdate - oldCovArea + area; //area after update would go through
                       if(areaSumAfterUpdate > forestArea){
                       System.out.println("\nPlease note that the total area of forests covering " + coverageState + " cannot exceed " + forestArea + ".\n" +
                                          "The total area of " + name + " is " + forestArea + " but your update would cause the coverage area to be " + areaSumAfterUpdate + ".\n");
                       }
                   }

               //update coverage --------------
                   String updateCoverage = "update coverage " +
                                           "set area = ? " +
                                           "where forest_no = ? and state = ?";
                   PreparedStatement pstUpCov = conn.prepareStatement(updateCoverage);
                   pstUpCov.setFloat(1, area);
                   pstUpCov.setString(2, forestNum);
                   //percentage is computed by trigger
                   pstUpCov.setString(3, coverageState);

                   pstUpCov.executeUpdate();

                   //print success message
                   System.out.println("\nThe coverage area has been updated to " + area + " for forest " + name + " in state " + coverageState + ".\n");

                   conn.commit();
            }
            catch(SQLException e) {
                while(e != null){
                    System.out.println("Message = " + e.getMessage());
                    System.out.println("SQLState = "+ e.getSQLState());
                    System.out.println("SQL Code = "+ e.getErrorCode());
                    e = e.getNextException();
                }
                try {
                    conn.rollback();
                } catch (SQLException e1) {
                    System.out.println(e1.toString());
                }
            }
        }
    }
}