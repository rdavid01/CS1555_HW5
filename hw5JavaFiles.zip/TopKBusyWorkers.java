// David Reidenbaugh (dmr117)
// Eric Copeland (ejc76)

//!!! switch url, user, and password from local host to class3 host before submittin
//ASSUMPTIOIN: if there is a tie, we will display (k) tuples and have smaller sensor_id first
import java.io.*;
import java.util.*;
import java.sql.*;

public class TopKBusyWorkers {
    public static void main(String args[]) throws
            ClassNotFoundException, SQLException {

        //check if jdbc driver is properly linked
        Class.forName("org.postgresql.Driver");

        //connection
        String url = "jdbc:postgresql://localhost:5432/";
//         String url = "jdbc:postgresql://class3.cs.pitt.edu:5432/";
        Properties props = new Properties();
        props.setProperty("user", "postgres");
//         props.setProperty("user", "dmr117");
        props.setProperty("password", "skuleStinks");
//         props.setProperty("password", "<password here>");

        //connection
        Connection conn = DriverManager.getConnection(url, props);

        Scanner userInput = new Scanner(System.in);

        int kVal = 0;
        boolean exceptionOccurred = false;

        //gather input from user
        //top-k number
        System.out.println("Provide a number (k) in order to see the busiest (k) workers." +
                            "(Ex. if you want to see the top 3 busiest workers, input \'3\')" +
                            "Please note that less than (k) workers may be displayed if there are not at least (k) workers who are busy.\n");
        try{
            kVal = userInput.nextInt();
        }
        catch(NoSuchElementException e){
            exceptionOccurred = true;
            System.out.println("\nNoSuchElementException for attribute name");
            System.out.println("Please try again and provide a numeric value for (k).");
        }

        if(!exceptionOccurred){
            try{
                //get busiest workers
                    //returns columns 'name', 'num_sensors', and 'rank'  in that order
                String busiestWorkers = "SELECT name, num_sensors, RANK() OVER (" +
                                            "ORDER BY num_sensors DESC " +
                                            ") AS rank " +
                                        "FROM ( " +
                                            "SELECT ssn, name, count(*) as num_sensors " +
                                            "FROM WORKER W JOIN SENSOR S ON W.ssn = S.maintainer " +
                                            "WHERE S.energy <= 2 " +
                                            "GROUP BY name, ssn " +
                                            "ORDER BY name asc " +
                                            ") AS SENSOR_WORKER " +
                                            "FETCH FIRST ? ROWS ONLY";


                PreparedStatement pst = conn.prepareStatement(busiestWorkers);
                pst.setInt(1, kVal);
                String workerName = null;
                int numSensors = 0;
                int rank = 0;

                System.out.println("The following workers have the most sensors to charge (are the busiest):");
                ResultSet rs = pst.executeQuery();
                while(rs.next()){
                    rank = rs.getInt("rank");
                    numSensors = rs.getInt("num_sensors");
                    workerName = rs.getString("name");
                    System.out.print("\tWorker's name: " + workerName);
                    System.out.print("\tNumber of sensors to charge: " + numSensors);
                    System.out.print("\tRank: " + rank + "\n");
                }

                if(workerName == null){
                    System.out.println("\tThere are no workers that need to charge a sensor.\n");
                }
            }
            catch(SQLException e) {
                while(e != null){
                    System.out.println("Message = " + e.getMessage());
                    System.out.println("SQLState = "+ e.getSQLState());
                    System.out.println("SQL Code = "+ e.getErrorCode());
                    e = e.getNextException();
                }
                try {
                    conn.rollback();
                } catch (SQLException e1) {
                    System.out.println(e1.toString());
                }
            }
        }
    }
}