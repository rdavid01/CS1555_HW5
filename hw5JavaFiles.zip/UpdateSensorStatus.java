// David Reidenbaugh (dmr117)
// Eric Copeland (ejc76)

//!!! switch url, user, and password from local host to class3 host before submittin
//ASSUMPTION: This class is for when the user wants to read a report from the sensor (ex. see temp, update last charge time, update energy).
            //The user will not use this to change the sensor's location.
import java.io.*;
import java.util.*;
import java.sql.*;

public class UpdateSensorStatus {
    public static void main(String args[]) throws
            ClassNotFoundException, SQLException {

        //check if jdbc driver is properly linked
        Class.forName("org.postgresql.Driver");

        //connection
        String url = "jdbc:postgresql://localhost:5432/";
//         String url = "jdbc:postgresql://class3.cs.pitt.edu:5432/";
        Properties props = new Properties();
        props.setProperty("user", "postgres");
//         props.setProperty("user", "dmr117");
        props.setProperty("password", "skuleStinks");
//         props.setProperty("password", "<password here>");

        //connection
        Connection conn = DriverManager.getConnection(url, props);

        Scanner userInput = new Scanner(System.in);

        float xCoord = 0;
        float yCoord = 0;
        int chargeMonth = 0;
        int chargeDay = 0;
        int chargeYear = 0;
        int chargeHour = 0;
        int chargeMinute = 0;
        int energy = 0;
        float temp = 0;
        boolean exceptionOccurred = false;


        //gather inputs from user one at a time
            //sensor id generated automatically at insertion time
        //x coordinate
        System.out.println("Please enter the sensor's x coordinate as a numeric value.");
        try{
            xCoord = userInput.nextFloat();
        }
        catch(NoSuchElementException e){
            exceptionOccurred = true;
            System.out.println("\nNoSuchElementException for attribute x coordinate.");
            System.out.println("Please try again and provide a numeric value.");
        }

        //y coordinate
        if(!exceptionOccurred){
            System.out.println("Please enter the sensor's y coordinate as a numeric value.");
            try{
                yCoord = userInput.nextFloat();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for attribute y coordinate");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //charge year
        if(!exceptionOccurred){
            System.out.println("Please enter year of sensor's last charge time."
                                +"\n (Ex. if the year was 2020, type \'2020\'.)");
            try{
                chargeYear = userInput.nextInt();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for charge year");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //charge month
        if(!exceptionOccurred){
            System.out.println("Please enter the month number of sensor's last charge time."
                                +"\n (Ex. if the month was January, type \'1\'.)");
            try{
                chargeMonth = userInput.nextInt();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for charge month");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //charge day
        if(!exceptionOccurred){
            System.out.println("Please enter the day number of the month of sensor's last charge time."
                                +"\n (Ex. if the day was the 12th of January, type \'12\'.)");
            try{
                chargeDay = userInput.nextInt();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for charge day");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //charge hour
        if(!exceptionOccurred){
            System.out.println("Please enter the hour (using 24-hour clock) of sensor's last charge time."
                                +"\n (Ex. if the hour was 5PM, type \'17\'.)");
            try{
                chargeHour = userInput.nextInt();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for charge hour");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //charge minute
        if(!exceptionOccurred){
            System.out.println("Please enter the minute of sensor's last charge time."
                                +"\n (Ex. if the time was was 5:25, type \'25\'.)");
            try{
                chargeMinute = userInput.nextInt();

            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for charge minute");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //energy
        if(!exceptionOccurred){
            System.out.println("Please provide energy level of this sensor as a numeric value.");
            try{
                energy = userInput.nextInt();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for attribute energy");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //temperature
        if(!exceptionOccurred){
            System.out.println("Please provide the temperature (in degrees Fahrenheit)this sensor is reporting as a numeric value.");
            try{
                temp = userInput.nextFloat();
            }
            catch(NoSuchElementException e){
                exceptionOccurred = true;
                System.out.println("\nNoSuchElementException for attribute energy");
                System.out.println("Please try again and provide a numeric value.");
            }
        }

        //use inputs to make timestamps
        String lastChargeStr = (chargeYear + "-" + chargeMonth + "-" + chargeDay
                                + " " + chargeHour + ":" + chargeMinute + ":" + "00");

        Timestamp lastChargeStamp = null;
        Timestamp lastReadStamp = null; //the new last read time will be set to the current time

        if(!exceptionOccurred){
            try{
                //timestamp using inputs
                lastChargeStamp = Timestamp.valueOf(lastChargeStr);
                //timestamp using current time
                Calendar newCal = Calendar.getInstance();
                java.util.Date currTime = newCal.getTime();
                lastReadStamp = new Timestamp(currTime.getTime());
            }
            catch(IllegalArgumentException e){
                exceptionOccurred = true;
                System.out.println("\nIllegalArgumentException for generating timestamp.");
                System.out.println("Please try again and make sure all dates and times provided are the appropriate lengths.");

            }
        }

        //update the db
        if(!exceptionOccurred){
            try{
                //start transaction and update DB
                conn.setAutoCommit(false);

                //update the sensor--------------------
                String updateSensor = "update sensor " +
                                      "set last_charged = ?, last_read = ?, energy = ? " +
                                      "where x = ? and y = ?";

                PreparedStatement pstUpdSens = conn.prepareStatement(updateSensor);
                pstUpdSens.setTimestamp(1, lastChargeStamp);
                pstUpdSens.setTimestamp(2, lastReadStamp);
                pstUpdSens.setInt(3, energy);
                pstUpdSens.setFloat(4, xCoord);
                pstUpdSens.setFloat(5, yCoord);

                pstUpdSens.executeUpdate();


                //get sensor's id---------------------
                String getSensorId = "select sensor_id " +
                                     "from sensor " +
                                     "where x = ? and y = ?";

                PreparedStatement pstGetSens = conn.prepareStatement(getSensorId);
                pstGetSens.setFloat(1, xCoord);
                pstGetSens.setFloat(2, yCoord);

                int id = 0;
                ResultSet currID = pstGetSens.executeQuery();
                while(currID.next()){
                    id = currID.getInt("sensor_id");
                }

                if(id == 0){
                    System.out.println("\nA sensor with the coordinates (" + xCoord + "," + yCoord + ") does not exist.");
                }


                //get number of records in emergency before inserting new report (baseline)--------
                    //check size of emergency (used to see if entry added to emergency)
                String getSize = "select count(*) as totalEntries " +
                                 "from emergency";
                PreparedStatement pstGetCount = conn.prepareStatement(getSize);
                int countBaseline = 0;
                ResultSet count = pstGetCount.executeQuery();
                while(count.next()){
                    countBaseline = count.getInt("totalEntries");
                }


                //insert report ------------------
                System.out.println("");
                String insertReport = "insert into report values(?, ?, ?)";

                PreparedStatement pstInsertReport = conn.prepareStatement(insertReport);
                pstInsertReport.setInt(1, id);
                pstInsertReport.setTimestamp(2, lastReadStamp);
                pstInsertReport.setFloat(3, temp);

                pstInsertReport.executeUpdate();


                //get number of recoreds in emergency after inserting new report (finalcount)------
                int finalCount = 0;
                count = pstGetCount.executeQuery(); //count is a ResultSet which is defined above
                while(count.next()){
                    finalCount = count.getInt("totalEntries");
                }


                //print success message
                if(finalCount == countBaseline){
                    System.out.println("No emergency detected.");
                }
                else{ //if new entry in emergency (emerency is based on a new tuple being inserted in the emergency table)
                    System.out.println("There is an EMERGENCY.  The temperature reported was " + temp + " degrees Fahrenheit.\n");
                }

                conn.commit();
            }
            catch(SQLException e){
                exceptionOccurred = true;
                while(e != null){
                    System.out.println("Message = " + e.getMessage());
                    System.out.println("SQLState = "+ e.getSQLState());
                    System.out.println("SQL Code = "+ e.getErrorCode());
                    e = e.getNextException();
                }
                try{
                   conn.rollback();
                }
                catch(SQLException e1){
                   System.out.println(e1.toString());
                }
            }
        }
    }
}